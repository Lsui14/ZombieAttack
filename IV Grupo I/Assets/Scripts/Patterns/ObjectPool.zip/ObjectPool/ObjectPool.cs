using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;
using Patterns.ObjectPool.Interfaces;
using Unity.VisualScripting;

namespace Patterns.ObjectPool
{
    public class ObjectPool : IObjectPool
    {

        private IPooleableObject _objectPrototype;
        private readonly bool _allowAddNew;
        private int initialNumber;
        private List<IPooleableObject> _objects;



        public ObjectPool(IPooleableObject objectPrototype, int initialNumberOfElements, bool allowAddNew)
        {
            _objectPrototype = objectPrototype;
            initialNumber = initialNumberOfElements;
            _allowAddNew = allowAddNew;
            _objects = new List<IPooleableObject>(initialNumberOfElements);

            for (int i = 0; i < initialNumberOfElements; i++)
            {
                _objects.Add(CreateObject());
            }
        }

        public IPooleableObject Get()
        {
            
            for (int i = 0; i < _objects.Count; i++)
            {

                if (!_objects[i].Active)
                {

                    _objects[i].Active = true;
                    return _objects[i];
                }
            }

            if (_allowAddNew)
            {
                
                IPooleableObject newObj = CreateObject();
                newObj.Active = true;
                _objects.Add(newObj);

                return newObj;
            }

            return null;
        }

        public void Release(IPooleableObject obj)
        {
            obj.Active = false;
            obj.Reset();
            if (_objects.Count > initialNumber)
            {
                _objects.Remove(obj);
                obj.Destroy();
            }
        }


        private IPooleableObject CreateObject()
        {
            IPooleableObject newObj = _objectPrototype.Clone();
            newObj.Active = false;
            return newObj;
        }
      
        
    }
}
