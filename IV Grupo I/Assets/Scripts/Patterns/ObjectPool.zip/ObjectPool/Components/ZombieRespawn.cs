using Patterns.ObjectPool;
using Patterns.ObjectPool.Interfaces;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class ZombieRespawn : MonoBehaviour
{
    //ObjectPool Variables
    public MonoBehaviour zombiePrototype;
    public int initialNumber = 5;
    public bool allowed = true;
    private ObjectPool _zombiePool;

    //Respawn Variables
    bool ronda = true;
    List<Transform> respawns = new List<Transform>();
    public float rate = 3f;
    public float rateTime = 0f;
    public float count = 0;

    void Start()
    {
        _zombiePool = new ObjectPool((IPooleableObject)zombiePrototype, initialNumber, allowed);
        GameObject spawns = GameObject.FindGameObjectWithTag("Respawns");
        foreach (Transform t in spawns.transform)
        {
            respawns.Add(t);
        }
    }

    private void CreateZombie()
    {

        if (count >= 30)
        {
            ronda = false;
        }
        else
        {
            Zombie zombie = (Zombie)_zombiePool.Get();
            if (zombie)
            {
                zombie.zombies = _zombiePool;
                Transform spawn = respawns[Random.Range(0, respawns.Count)];
                zombie.transform.localPosition = spawn.position;
                zombie.HP = 100;
                zombie.animator.SetBool("Alive", true);
                zombie.GetComponent<Collider>().enabled = true;
                count++;

            }
        }
    }

    void Update()
    {

        if (ronda && Time.time > rateTime)
        {

            CreateZombie();
            rateTime = Time.time + rate;

        }

    }
}
