using Patterns.Command.Interfaces;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour, IPlayerReceiver
{

    //private Vector3 _newPosition;

    //Movement
    public float speed = 10f;
    public float jump = 3f;
    public bool isSprinting;
    public float staminaUseAmount = 5;
    public float sprintingSpeedMultiplier = 1.5f;
    private float sprintSpeed = 1;
    public CharacterController characterController;

    //Collisions
    public Transform collision;
    public Transform collisionCeil;
    public float radius = 0.3f;
    public LayerMask collisionMask;
    bool isTouching;
    public float gravity = -9.8f;
    Vector3 velocity;

    //Stats
    public int HP = 100;
    public int HP_Max = 100;

    //UI
    private UIStamina staminaSlider;
    private Slider slider;


    private void Awake()
    {
        GameObject go = GameObject.FindGameObjectWithTag("Vida");
        slider = go.GetComponent<Slider>();
        staminaSlider = FindObjectOfType<UIStamina>();
        slider.maxValue = HP_Max;
        slider.value = HP;
    }


    public void Jump()
    {
        isTouching = Physics.CheckSphere(collision.position, radius, collisionMask);


        if (isTouching)
        {
            velocity.y = Mathf.Sqrt(jump * -2 * gravity);
        }
    }

    public void MoveRight(float x)
    {
        Vector3 move = transform.right * x;

        characterController.Move(move * speed * Time.deltaTime * sprintSpeed);
    }

    public void MoveForward(float z)
    {

        Vector3 move = transform.forward * z;

        characterController.Move(move * speed * Time.deltaTime * sprintSpeed);
    }

    public void TakeDamage(int damage)
    {
        HP = Mathf.Max(0, HP - damage);
        slider.value = HP;
        if (HP <= 0)
        {
            Cursor.lockState = CursorLockMode.None;
            SceneManager.LoadScene(2);
        }
    }

    public void Health(int health)
    {
        HP = Mathf.Min(HP_Max, HP + health);
        slider.value = HP;
    }

    public void Sprint()
    {
        isSprinting = !isSprinting;

        if (isSprinting)
        {
            staminaSlider.UseStamina(staminaUseAmount);
        }

        else
        {
            staminaSlider.UseStamina(0);
        }



    }

    void Update()
    {
        
        isTouching = Physics.CheckSphere(collision.position, radius, collisionMask);

        if (isSprinting)
        {
            sprintSpeed = sprintingSpeedMultiplier;
        }

        else
        {
            sprintSpeed = 1;
        }

        if (isTouching && velocity.y < 0)
        {
            velocity.y = -3f;
            
        }

        velocity.y += gravity * Time.deltaTime;

        characterController.Move(velocity * Time.deltaTime);

    }

}
