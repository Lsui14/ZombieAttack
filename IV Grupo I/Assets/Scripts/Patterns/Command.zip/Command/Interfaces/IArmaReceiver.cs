using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IArmaReceiver
{
    public void Reload();

    public void Shoot();

}
