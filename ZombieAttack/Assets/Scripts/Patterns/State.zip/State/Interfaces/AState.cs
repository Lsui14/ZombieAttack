using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class AState : IState
{
    protected IState contexto;
    protected Animator animator;

    public AState(IState contexto, Animator animator)
    {
        this.contexto = contexto;
        this.animator = animator;
    }

    public abstract void Enter();
    public abstract void Exit();
    public abstract void Update();

}
